export class IStudent{
    id: string;
    name: string;
}